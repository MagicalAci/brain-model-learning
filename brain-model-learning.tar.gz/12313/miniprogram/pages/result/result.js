Page({
  data: {
    ipId: null,
    modelId: null,
    result: null,
    achievements: [
      {
        id: 1,
        title: '团队管理专家',
        description: '完成团队管理模型学习',
        icon: '/images/achievement1.png'
      },
      {
        id: 2,
        title: '决策思维大师',
        description: '完成决策思维模型学习',
        icon: '/images/achievement2.png'
      },
      {
        id: 3,
        title: '商业洞察专家',
        description: '完成商业洞察模型学习',
        icon: '/images/achievement3.png'
      }
    ]
  },

  onLoad(options) {
    const { ipId, modelId } = options
    this.setData({ ipId, modelId })
    this.loadResult()
  },

  loadResult() {
    const app = getApp()
    const progress = app.globalData.learningProgress
    const currentModel = progress.models.find(m => m.id === parseInt(this.data.modelId))
    
    this.setData({
      result: {
        modelName: currentModel.name,
        progress: currentModel.progress,
        completed: currentModel.progress === 100
      }
    })
  },

  onShareTap() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    })
  },

  onBackHome() {
    wx.switchTab({
      url: '/pages/index/index'
    })
  },

  onShareAppMessage() {
    return {
      title: '我在IP克隆学习小程序中获得了新成就！',
      path: '/pages/index/index',
      imageUrl: '/images/share.png'
    }
  }
}) 