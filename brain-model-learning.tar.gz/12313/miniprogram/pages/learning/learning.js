Page({
  data: {
    ipId: null,
    ipInfo: null,
    progress: {
      total: 0,
      current: 0,
      percentage: 0
    },
    models: [
      {
        id: 1,
        name: '团队管理模型',
        description: '学习此模型可提升团队管理效率',
        status: 'unlocked',
        progress: 0
      },
      {
        id: 2,
        name: '决策思维模型',
        description: '学习此模型可提升决策速度',
        status: 'locked',
        progress: 0
      },
      {
        id: 3,
        name: '商业洞察模型',
        description: '学习此模型可提升商业判断力',
        status: 'locked',
        progress: 0
      }
    ]
  },

  onLoad(options) {
    const { ipId } = options
    this.setData({ ipId })
    this.loadIPInfo()
    this.loadProgress()
  },

  loadIPInfo() {
    // TODO: 从云数据库加载IP信息
    const app = getApp()
    const ipCards = app.globalData.ipCards
    const ipInfo = ipCards.find(card => card.id === parseInt(this.data.ipId))
    this.setData({ ipInfo })
  },

  loadProgress() {
    const app = getApp()
    const progress = app.globalData.learningProgress
    this.setData({
      progress: {
        total: this.data.models.length,
        current: progress.unlockedModels.length,
        percentage: Math.round((progress.unlockedModels.length / this.data.models.length) * 100)
      }
    })
  },

  onModelTap(e) {
    const { modelId } = e.currentTarget.dataset
    const model = this.data.models.find(m => m.id === modelId)
    
    if (model.status === 'locked') {
      wx.showToast({
        title: '请先完成前置模型',
        icon: 'none'
      })
      return
    }

    wx.navigateTo({
      url: `/pages/model/model?ipId=${this.data.ipId}&modelId=${modelId}`
    })
  }
}) 