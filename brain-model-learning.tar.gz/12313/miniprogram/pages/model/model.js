Page({
  data: {
    ipId: null,
    modelId: null,
    modelInfo: null,
    knowledgePoints: [
      {
        id: 1,
        title: '核心原则',
        content: '团队管理的核心是建立信任和明确目标。通过有效的沟通和激励机制，让团队成员自发地朝着共同目标努力。',
        image: '/images/knowledge1.png'
      },
      {
        id: 2,
        title: '实践方法',
        content: '1. 每周团队会议\n2. 目标分解与追踪\n3. 及时反馈与调整\n4. 建立激励机制',
        image: '/images/knowledge2.png'
      },
      {
        id: 3,
        title: '常见误区',
        content: '1. 过度控制\n2. 目标不明确\n3. 沟通不畅\n4. 激励不足',
        image: '/images/knowledge3.png'
      }
    ],
    currentIndex: 0,
    showTest: false,
    questions: [
      {
        id: 1,
        question: '当团队成员提出新的想法时，你应该：',
        options: [
          { id: 'A', text: '立即采纳并实施' },
          { id: 'B', text: '仔细评估后决定' },
          { id: 'C', text: '直接否决' },
          { id: 'D', text: '推给其他同事处理' }
        ],
        correct: 'B'
      },
      {
        id: 2,
        question: '团队目标设定时，最重要的是：',
        options: [
          { id: 'A', text: '目标要远大' },
          { id: 'B', text: '目标要具体可执行' },
          { id: 'C', text: '目标要容易完成' },
          { id: 'D', text: '目标要保密' }
        ],
        correct: 'B'
      },
      {
        id: 3,
        question: '面对团队冲突，最佳处理方式是：',
        options: [
          { id: 'A', text: '置之不理' },
          { id: 'B', text: '立即介入调解' },
          { id: 'C', text: '让团队成员自行解决' },
          { id: 'D', text: '开除相关成员' }
        ],
        correct: 'B'
      }
    ],
    currentQuestion: 0,
    score: 0,
    showResult: false
  },

  onLoad(options) {
    const { ipId, modelId } = options
    this.setData({ ipId, modelId })
    this.loadModelInfo()
  },

  loadModelInfo() {
    // TODO: 从云数据库加载模型信息
    const app = getApp()
    const models = app.globalData.models
    const modelInfo = models.find(m => m.id === parseInt(this.data.modelId))
    this.setData({ modelInfo })
  },

  onScrollToLower() {
    if (!this.data.showTest) {
      this.setData({ showTest: true })
    }
  },

  onOptionSelect(e) {
    const { optionId } = e.currentTarget.dataset
    const currentQuestion = this.data.questions[this.data.currentQuestion]
    
    if (optionId === currentQuestion.correct) {
      this.setData({
        score: this.data.score + 1
      })
    }

    if (this.data.currentQuestion < this.data.questions.length - 1) {
      this.setData({
        currentQuestion: this.data.currentQuestion + 1
      })
    } else {
      this.showResult()
    }
  },

  showResult() {
    const score = this.data.score
    const total = this.data.questions.length
    const percentage = Math.round((score / total) * 100)
    
    this.setData({
      showResult: true,
      result: {
        score,
        total,
        percentage
      }
    })

    // 更新学习进度
    this.updateProgress(percentage)
  },

  updateProgress(percentage) {
    const app = getApp()
    const progress = app.globalData.learningProgress
    
    // 更新当前模型进度
    const models = progress.models.map(model => {
      if (model.id === parseInt(this.data.modelId)) {
        return { ...model, progress: percentage }
      }
      return model
    })

    // 如果完成度达到100%，解锁下一个模型
    if (percentage === 100) {
      const nextModelId = parseInt(this.data.modelId) + 1
      const nextModel = models.find(m => m.id === nextModelId)
      if (nextModel) {
        nextModel.status = 'unlocked'
      }
    }

    app.globalData.learningProgress = {
      ...progress,
      models
    }
  },

  onContinueTap() {
    if (this.data.result.percentage >= 80) {
      // 如果得分超过80%，进入下一个模型
      const nextModelId = parseInt(this.data.modelId) + 1
      wx.redirectTo({
        url: `/pages/model/model?ipId=${this.data.ipId}&modelId=${nextModelId}`
      })
    } else {
      // 否则返回学习列表
      wx.navigateBack()
    }
  }
}) 