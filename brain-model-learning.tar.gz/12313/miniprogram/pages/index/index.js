Page({
  data: {
    ipCards: [
      {
        id: 1,
        title: '百亿身价创始人',
        name: '张明',
        avatar: '/images/avatar1.png',
        achievements: [
          '10年打造3家独角兽',
          '管理万人团队方法论',
          '快速决策系统'
        ],
        learnableSkills: [
          '团队管理能力',
          '决策思维',
          '商业洞察'
        ]
      },
      {
        id: 2,
        title: '互联网产品专家',
        name: '李华',
        avatar: '/images/avatar2.png',
        achievements: [
          '打造10亿级产品',
          '用户增长方法论',
          '产品创新思维'
        ],
        learnableSkills: [
          '产品规划',
          '用户运营',
          '数据分析'
        ]
      },
      {
        id: 3,
        title: '投资决策专家',
        name: '王强',
        avatar: '/images/avatar3.png',
        achievements: [
          '投资回报率300%',
          '风险控制体系',
          '市场分析模型'
        ],
        learnableSkills: [
          '投资分析',
          '风险控制',
          '市场洞察'
        ]
      }
    ],
    currentIndex: 0
  },

  onLoad() {
    // 埋点：页面曝光
    this.trackPageView()
  },

  // 卡片切换
  onCardChange(e) {
    const { current } = e.detail
    this.setData({
      currentIndex: current
    })
    // 埋点：卡片切换
    this.trackCardSwitch(current)
  },

  // 点击克隆按钮
  onCloneTap() {
    const currentIP = this.data.ipCards[this.data.currentIndex]
    // 埋点：克隆按钮点击
    this.trackCloneClick(currentIP.id)
    
    wx.navigateTo({
      url: `/pages/learning/learning?ipId=${currentIP.id}`
    })
  },

  // 埋点方法
  trackPageView() {
    // TODO: 实现页面曝光埋点
  },

  trackCardSwitch(index) {
    // TODO: 实现卡片切换埋点
  },

  trackCloneClick(ipId) {
    // TODO: 实现克隆按钮点击埋点
  }
}) 