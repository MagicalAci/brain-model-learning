App({
  globalData: {
    userInfo: null,
    learningProgress: {
      totalProgress: 0,
      unlockedModels: [],
      currentModel: null
    }
  },
  onLaunch() {
    // 初始化云开发环境
    if (wx.cloud) {
      wx.cloud.init({
        env: 'your-env-id',
        traceUser: true
      })
    }
  }
}) 