# IP克隆学习H5应用

这是一个基于HTML5的IP克隆学习应用，提供知识学习和测试功能。

## 在线访问

您可以通过以下地址访问本应用：
- GitHub Pages: https://[你的GitHub用户名].github.io/brain-model-learning/

## 功能特点

- 知识卡片展示
- 学习进度追踪
- 知识测试
- 成就系统
- 分享功能

## 本地部署步骤

1. 确保已安装Node.js（建议版本 >= 14.0.0）

2. 克隆项目到本地：
```bash
git clone https://github.com/[你的GitHub用户名]/brain-model-learning.git
cd brain-model-learning
```

3. 安装依赖：
```bash
npm install
```

4. 启动服务器：
```bash
npm start
```
或使用Python简易服务器：
```bash
python3 -m http.server
```

5. 访问应用：
打开浏览器访问 http://localhost:3000 或 http://localhost:8000

## 项目结构

```
brain-model-learning/
├── index.html          # 首页
├── learning.html       # 学习列表页
├── model_detail.html   # 模型详情页
├── model_test.html     # 模型测试页
├── result.html         # 结果页
├── server.js           # 服务器文件
├── package.json        # 项目配置文件
└── README.md           # 项目说明文档
```

## 开发说明

- 所有页面都采用响应式设计，适配移动端和桌面端
- 使用原生JavaScript实现交互功能
- 采用模块化的CSS样式组织

## GitHub Pages部署说明

本项目已配置为使用GitHub Pages自动部署。每次推送到master分支后，更新将自动发布到GitHub Pages。

## 注意事项

- 确保服务器端口未被占用
- 建议使用现代浏览器访问以获得最佳体验
- 在GitHub Pages上部署时，某些需要后端支持的功能可能无法正常工作

## 技术支持

如有问题，请通过GitHub Issues提交问题。 