#!/bin/bash

# 颜色定义
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}====================================${NC}"
echo -e "${GREEN}   模慧AI - 本地部署工具    ${NC}"
echo -e "${GREEN}====================================${NC}"

# 检查Python是否已安装
if command -v python3 &>/dev/null; then
    PYTHON_CMD="python3"
elif command -v python &>/dev/null; then
    PYTHON_CMD="python"
else
    echo -e "${RED}错误: 未找到Python。请安装Python后再试。${NC}"
    exit 1
fi

# 获取本地IP地址
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    IP=$(ifconfig | grep "inet " | grep -v 127.0.0.1 | head -1 | awk '{print $2}')
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux
    IP=$(hostname -I | awk '{print $1}')
else
    # 默认
    IP="localhost"
fi

# 改进的端口检测函数
find_available_port() {
    local port=8000
    local max_port=8100
    
    while [ $port -le $max_port ]; do
        # 尝试绑定到端口以检查其可用性
        (echo "" > /dev/tcp/127.0.0.1/$port) >/dev/null 2>&1
        if [ $? -ne 0 ]; then
            # 端口不可用时命令会失败（返回非零），这表示端口是可用的
            echo $port
            return 0
        fi
        port=$((port+1))
    done
    
    # 如果我们到达这里，表示没有找到可用端口
    echo -e "${RED}错误: 无法找到可用端口（8000-${max_port}）${NC}"
    exit 1
}

# 简单的端口检测函数，适用于大多数系统
is_port_available() {
    local port=$1
    nc -z localhost $port >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        return 0 # 端口可用
    else
        return 1 # 端口已占用
    fi
}

# 使用循环查找可用端口
port=8000
max_port=8100

while [ $port -le $max_port ]; do
    $PYTHON_CMD -c "import socket; s=socket.socket(); s.bind(('', $port)); s.close(); exit(0)" >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        PORT=$port
        break
    fi
    port=$((port+1))
done

if [ -z "$PORT" ]; then
    echo -e "${RED}错误: 无法找到可用端口（8000-${max_port}）${NC}"
    exit 1
fi

URL="http://$IP:$PORT"
LOCAL_URL="http://localhost:$PORT"

echo -e "${BLUE}启动本地服务器...${NC}"
echo -e "${BLUE}您可以通过以下地址访问:${NC}"
echo -e "${GREEN}本机访问: ${LOCAL_URL}${NC}"
echo -e "${GREEN}同一网络其他设备访问: ${URL}${NC}"
echo -e "${BLUE}按 Ctrl+C 停止服务器${NC}"
echo ""

# 启动Python HTTP服务器
if [[ "$PYTHON_CMD" == "python3" ]]; then
    $PYTHON_CMD -m http.server $PORT
else
    $PYTHON_CMD -m SimpleHTTPServer $PORT
fi 